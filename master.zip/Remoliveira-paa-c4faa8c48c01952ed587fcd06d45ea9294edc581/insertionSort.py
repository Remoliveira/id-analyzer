import time
import random


def insertionSort(lista):

    for i in range (1,len(lista)):
        
        key = lista[i]
        k = i

        while(k > 0 and key < lista[k-1]):
            lista[k] = lista[k - 1]
            k-= 1
        lista[k] = key

    # print(lista)
    return lista


def main():

    x = [-65,1,84561,848,112,66,484,2,56,87,151,5151,544,5,5,4,2,5,8,56,189,6265,9568,8595,5956222,0]
    y = list(range(0,100000))
    random.shuffle(y)
    # print(x)
    insertionSort(y)

if __name__ == '__main__':
    
    inicio = time.time()
   
    main()

    fim = time.time()
    tempo = fim-inicio
    print(tempo)
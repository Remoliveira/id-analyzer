import socket
import sys
import os 
import re
import pickle



HOST = '127.0.0.1'  # Standard loopback interface address (localhost)
PORT = 65431        # Port to listen on (non-privileged ports are > 1023)

dados = [{
    "Nome":"remo",
    "Idade":25,
    "Sexo":4
},{
    "Nome":"Thauana",
    "Idade":24,
    "Sexo":5
}
]


with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    s.listen()
    conn, addr = s.accept()
    
    with conn:
        print('Connectado por: ', addr)
        
        while True:

            tamanhoHeader = 10
            data = conn.recv(1024).decode()
            dataFormat = data.split(':$')

            

            if(data == "SELECT*" or data == "select"):
                print("select")
                print(dados)

                message = pickle.dumps(dados)
                message = bytes(f'{len(message):<{tamanhoHeader}}',"UTF-8") + message

                conn.send(message)
               

            elif(dataFormat[0] == "INSERT" and len(dataFormat) == 4):

                print("nome: ", dataFormat[1], "idade: ", dataFormat[2], "sexo: ", dataFormat[3])
                print(type(dataFormat[1]), dataFormat[1])

                dicionario ={
                    "Nome":dataFormat[1],
                    "Idade":dataFormat[2],
                    "Sexo":dataFormat[3]
                }

                dados.append(dicionario)
                dataFormat = None
                conn.sendall("Nome inserido".encode())

            elif(data == "1"):
             
                conn.sendall("Fim da conexão".encode())
                conn.close()
                break
            else:
              
                conn.sendall("Entrada incorreta".encode())

            # print("Esperando")
            
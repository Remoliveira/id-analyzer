import socket
import sys
import os
import pickle

HOST = '127.0.0.1'  # The server's hostname or IP address
PORT = 65431       # The port used by the server
tamanhoHeader = 10
dados = None

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
  
    
    while(dados != "1"):
        print("opcao: ")

        dados = input()
        s.send(dados.encode())

        if(dados == "select" or dados == "SELECT*" or dados == "select*"):  
            
            mensagemRecv = b''
            novaMsg = True
            rec = True
            
            while(rec):

                message = s.recv(1024)
                if novaMsg:
           
                    # print(f"tamanho da nova mensagem: {message[:tamanhoHeader]}")
                    tamanhoMensagem = int(message[:tamanhoHeader])
                    novaMsg = False
      
                mensagemRecv += message 
         
                if len(mensagemRecv)-tamanhoHeader == tamanhoMensagem:
                    # print("recebido toda msg")
                    # print(mensagemRecv[tamanhoHeader:])

                    mensagemDecode = pickle.loads(mensagemRecv[tamanhoHeader:])
                    # print(mensagemDecode)
                    print("Base de dados:\n")
                    
                    for mensagem in mensagemDecode:

                        print("Nome: ",mensagem["Nome"])
                        print("Idade: ",mensagem["Idade"])
                        print("Sexo: ",mensagem["Sexo"],"\n")

                    novaMsg = True
                    mensagemRecv = b''
                    rec = False

        
        elif(dados.startswith("INSERT")):
       
            data =  s.recv(1024).decode() 
            print("Received", repr(data))

        elif(dados == "1"):

            data =  s.recv(1024).decode() 
            print("Received", repr(data))
            s.close()

        else:

            data =  s.recv(1024).decode() 
            print("Received", repr(data))
        

        









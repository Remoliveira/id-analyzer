import random

    # listas = [None] 
    # while(len(listasMerge) >=3 ):

    #     # print("aqui--->  ",len(listasMerge))

    #     if(len(listasMerge[-1]) + len(listasMerge[-2]) < len(listasMerge[-3])):

    #         if(len(listasMerge[-1] > len(listasMerge[-2]))):

    #             listas = [None] * (len(listasMerge[-1]) + len(listasMerge[-2]))
    #             # print("oi")
    #             temp =  ms.merge(listas,listasMerge[-1],listasMerge[-2])
    #             # print(temp)
    #             listasMerge.pop()
    #             listasMerge.pop()
             
    #             listasMerge.append(temp)
    #         else:
    #             if(len(listasMerge[-1] > len(listasMerge[-3]))):
    #                 minimo = -3
    #             else:
    #                 minimo = -1
    #             listas = [None] * (len(listasMerge[-2]) + len(listasMerge[minimo]))
    #             # print("oi")
    #             temp =  ms.merge(listas,listasMerge[-2],listasMerge[minimo])
    #             # print(temp)
    #             listasMerge.pop()
    #             listasMerge.pop()
    #             listasMerge.append(temp)


def main():

    x = [353,6346,6466,43,6567,8688,34346,88658,43136]
    x = list(range(0,1000))
    random.shuffle(x)
   
    print(x.sort)


if __name__ == '__main__':

    main()

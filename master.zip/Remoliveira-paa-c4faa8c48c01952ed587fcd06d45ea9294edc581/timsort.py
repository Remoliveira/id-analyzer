import time
import random
import insertionSort as ins
import mergeSort as ms

def minRunCalc(n):

    r = 0

    while(n >= 64):
        r |= n & 1
        n >>= 1

    return n + r


def timSort(lista):

    tamanhoLista = len(lista)
    listaAux = []
    count = 0
    listasMerge = []
   

    if(tamanhoLista < 64):
        listaOrdenada = ins.insertionSort(lista)
        # print(listaOrdenada)
        return listaOrdenada
        
    else:
        
        # minRun =  minRunCalc(tamanhoLista)
        # print(minRun)
        minRun = 1024

    runAtual = minRun
   

    for i in range(0,tamanhoLista):
        
        listaAux.append(lista[i])
        # count+=1
        # print(count)
       
    
        if((i == runAtual) or (i == tamanhoLista-1)):
            listaAux = ins.insertionSort(listaAux)
            # print(listaAux)
            listasMerge.append(listaAux)
            listaAux = []
            count = 0
            runAtual = runAtual + minRun

            #while para fazer o merge nessa parte, nao só la depois
            

    # for i in range(len(listasMerge)):
        # print(listasMerge[i])
        # print(len(listasMerge)






    # listas = [None] * (len(listasMerge[-1]) + len(listasMerge[-2]))
    # listaOrdenada =  ms.merge(listas,listasMerge[-1],listasMerge[-2])
    # # print(listaOrdenada)
    # return listaOrdenada
    
    
    
    # print("\n")
    # print(listasMerge[-1])
    # listasMerge.pop()
    # print("\n")
    # print(listasMerge[-1])
     
            
   
        
# op2
    while(len(listasMerge) >=3 ):

        # print("aqui--->  ",len(listasMerge))

        if(len(listasMerge[-1]) + len(listasMerge[-2]) >= len(listasMerge[-3])):

            listas = [None] * (len(listasMerge[-1]) + len(listasMerge[-2]))
            # print("oi")
            temp =  ms.merge(listas,listasMerge[-1],listasMerge[-2])
            # print(temp)
            listasMerge.pop()
            listasMerge.pop()
            listasMerge.append(temp)

    listas = [None] * (len(listasMerge[-1]) + len(listasMerge[-2]))
    listaOrdenada =  ms.merge(listas,listasMerge[-1],listasMerge[-2])
    # print(listaOrdenada)
    return listaOrdenada

   #op1 
    # while(len(listasMerge) >=3 ):
    #     print("aqui--->  ",len(listasMerge))
    #     if(len(listasMerge[-1]) + len(listasMerge[-2]) >= len(listasMerge[-3])):
    #         print("oi")
    #         listas = ms.merge(listas,listasMerge[-1],listasMerge[-2])
    #         print(listas)
    #         listasMerge.pop()
    #         listasMerge.pop()

    #     listas = ms.merge(lista,listasMerge[-1],listasMerge[-2])



def main():

    x = [353,6346,6466,43,6567,8688,34346,88658,43136]
    x = list(range(0,1000000))
    random.shuffle(x)
    #print(x)
    inicio = time.time()
    timSort(x)
    fim = time.time()

    print("tempo: ", fim-inicio, "segundos")
    



if __name__ == '__main__':

    main()

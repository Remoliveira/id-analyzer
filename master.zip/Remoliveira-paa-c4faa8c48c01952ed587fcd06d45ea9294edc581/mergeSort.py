import time
import random


def mergeSort(lista):

    tamanho = len(lista)

    if(tamanho > 1):
        
        metadeLista = len(lista)//2

        listaEsquerda = lista[:metadeLista]
        # print(listaEsquerda)
        # print(type(listaEsquerda))
        listaDireita = lista[metadeLista:]
        # print((type(listaDireita)))
        # print(listaDireita)

        mergeSort(listaEsquerda)
        mergeSort(listaDireita)
       
        
        listaOrdenada = merge(lista,listaEsquerda,listaDireita)
        return listaOrdenada
    

def merge(lista,esquerda,direita):

    i = 0 
    j = 0
    k = 0  
    # print(type(esquerda))
    while(i < len(esquerda) and j < len(direita)):

        if(esquerda[i] > direita[j]):
            lista[k] = direita[j]
            # listaAux.append(direita[j])
            j+=1
        else:
            lista[k] = esquerda[i]
            # listaAux.append(esquerda[i])
            i+=1
        k+=1

    while(i < len(esquerda)):
        
        lista[k] = esquerda[i]
        # listaAux.append(esquerda[i])
        i+=1
        k+=1

    while(j < len(direita)):
        
        lista[k] = direita[j]
        # listaAux.append(direita[j])
        j+=1
        k+=1
    # print(lista)
    return lista


if __name__ == '__main__':

    inicio = time.time()

    vetor = [-65,1,84561,848,112,66,484,2,56,87,151,5151,544,5,5,4,2,5,8,56,189,6265,9568,8595,5956222,0,777777777,-84]
    vetor = list(range(0,100000))
    random.shuffle(vetor)
    vetor = mergeSort(vetor)

    fim = time.time()
    print("tempo: ", fim-inicio, "segundos")
    # print(vetor)

    # q = list(range(0,100))
    # print(q)
    # # q = list(range(1,1000000))
    # random.shuffle(q)
    # print(q)

   
    